<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Pencarian - Rahasae</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>

    <main class="content-center" style="padding: 2rem 1rem;">

        <?php if(!$catatans->isEmpty()): ?>
            
            <div class="search-query-display">Hasil untuk: "<?php echo e($query); ?>"</div>

            
            <div class="results-grid">
                <?php $__currentLoopData = $catatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <a href="/catatan/<?php echo e($catatan->kode_unik); ?>" class="result-card">
                        <div class="result-card-label"><?php echo e($catatan->penerima_nama); ?></div>
                        <div class="result-card-preview">
                            <?php echo e(Str::limit($catatan->pesan, 10, '...')); ?>

                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a href="/cari" class="catatan-back-button">Cari yang lain</a>

        <?php else: ?>
            
            <div class="success-card">
                <h1 class="success-title" style="font-size:1.8rem;">Oops!</h1>
                <p class="success-message">
                    Tidak ada catatan yang ditemukan untuk "<?php echo e($query); ?>".
                </p>
                <a href="/cari" class="success-button" style="margin-top:1.5rem;">Coba Cari Lagi</a>
            </div>
        <?php endif; ?>
    </main>

</body>
</html><?php /**PATH C:\xampp-8\htdocs\rahasae\resources\views/hasil.blade.php ENDPATH**/ ?>